#include <sys/types.h>
#include <sys/socket.h>
#include <net/if_ppp.h>
#include <sys/ioctl.h> 

#include "syslog.h"
#include "pppd.h"
#include "fsm.h"
#include "ipcp.h"
#include "upap.h"

#ifdef	CBCP
#include "lcp.h"
#include "cbcp.h"
#endif

#include "plugin.h"
#include "radlib.h"

#ifdef PPP_FILTER
#include <pcap.h>
#include <pcap-int.h>   /* XXX: To get struct pcap */
#define _PATH_FILTERS   "/etc/ppp/filters"
#endif

#define RAD_ALIVE   3
#define RAD_VPN     11
#define RAD_SHAPE   80
#define RAD_MAXMB   81
#define RAD_IP_POOL 82


#define RAD_SUCCESS     1                                                                      
#define RAD_FAILURE     0                                                                      

#define RAD_TRAFFIC_IN	85
#define RAD_TRAFFIC_OUT	86
#define RAD_ACCT_INTERIM_INTERVAL        87

#define RAD_ASCEND_CBCP_MODE		113


int rad_init(void);
int rad_pap_auth(char *user,char *passwd);
int rad_chap_auth(char *usern, u_char *remmd,int remmd_len, chap_state *cstate);
int rad_start(void);
int rad_stop(void);
int rad_alive(void);
int ip_up(void);
int ip_down(void);
int ip_active(char *pkt,int len);

static int radlogin(struct rad_handle*);
static rad_fast_send_request(struct rad_handle*);

#ifdef PPP_FILTER 
static char *get_filter __P((char *));
static int  split __P((char *, char *[], int, char *, size_t));
#endif

static struct rad_handle *rad_acct_init(void);

static char *clid;
static char *cid;
static int shape = 0;
static int traffic_limit = 0;
static int in_limit = 0;
static int out_limit = 0;
static int return_code = 0;

static char radacc_session_id[16];
static time_t s_time,e_time;


struct plugins pppd_plugin = {
    "expppd radius VPN plugin",
    rad_init,
    rad_pap_auth,
    rad_chap_auth,
    rad_start,
    rad_alive,
    rad_stop,
    ip_up,
    ip_down,
    ip_active,
// Data
    0,
    0,
    0,
    0
};

int ip_active(char *pkt,int len) {
}

int rad_init(void) {
    if((clid=(char*)getenv("clid")) == NULL ) clid = "unknown";
    if((cid=(char*)getenv("cid")) == NULL ) cid = "unknown";
    (void) srandomdev();
    snprintf(radacc_session_id, sizeof(radacc_session_id),
				"%ld",(long) random());
}

int ip_up(void) {
    char *argv[7],strspeed[32];
    sprintf(strspeed, "%d", shape);
    argv[0] = "/etc/ppp/shape.ppp";
    argv[1] = "Start";
    argv[2] = ifname;
    argv[3] = strspeed;
    argv[4] = peer_authname;
    argv[5] = devnam;
    argv[6] = NULL;
    run_program("/etc/ppp/shape.ppp", argv, 0);
}

int ip_down(void) {
    char *argv[7],strspeed[32];
    sprintf(strspeed, "%d", shape);
    argv[0] = "/etc/ppp/shape.ppp";
    argv[1] = "Stop";
    argv[2] = ifname;
    argv[3] = strspeed;
    argv[4] = peer_authname;
    argv[5] = devnam;
    argv[6] = NULL;
    run_program("/etc/ppp/shape.ppp", argv, 0);
}

static int rad_fast_send_request(struct rad_handle *rh) {
    struct timeval tv;
    int fd,n;

    n = rad_init_send_request(rh, &fd, &tv);
    if (n != 0) return n;
    n = rad_continue_send_request(rh, n, &fd, &tv);
    return 0;
}


static int radlogin(struct rad_handle *rh) {
    int attrtype,ret,sr;
    struct in_addr pin;
    char *s,*s1;
    const void *attrval;
    size_t attrlen;
    extern ipcp_options ipcp_wantoptions[];
    extern int alive_interval;
    
#ifdef CBCP
    lcp_options *go = &lcp_gotoptions[0];
#endif /* CBCP */ 

#ifdef PPP_FILTER
    pcap_t pc;
#endif /* PPP_FILTER */
    
    ret = RAD_FAILURE;

	rad_put_int(rh,RAD_SERVICE_TYPE, RAD_VPN);
	rad_put_string(rh, RAD_CALLING_STATION_ID, clid);
	rad_put_string(rh, RAD_CALLED_STATION_ID, cid);
	rad_put_int(rh, RAD_LOGIN_SERVICE, getpid());
	sr = rad_send_request(rh);
	if (sr == -1) return ret;
	if (sr != RAD_ACCESS_ACCEPT) return ret;

	while ((attrtype = rad_get_attr(rh, &attrval, &attrlen)) > 0) {
	    switch (attrtype) {
		case RAD_IDLE_TIMEOUT:
		    idle_time_limit = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Idle Timeout: %d",idle_time_limit);
		    break;
		    
		case RAD_TRAFFIC_IN:
		    in_limit = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Input traffic limit: %dbytes",in_limit);
		    break;
		case RAD_TRAFFIC_OUT:
		    out_limit = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Output traffic limit: %dbytes",out_limit);
		    break;
		case RAD_MAXMB:
		    traffic_limit = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Total traffic limit: %dbytes",traffic_limit);
		    break;
		case RAD_ACCT_INTERIM_INTERVAL:
		    alive_interval = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Alive interval: %d sec.",alive_interval);
		    break;
		case RAD_SHAPE:
		    shape = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Traffic-Shape %dKbit/sec",shape);
		    break;
		case RAD_FRAMED_IP_ADDRESS:
		    pin = rad_cvt_addr(attrval);
		    if (pin.s_addr != 0xFEFFFFFF) ipcp_wantoptions[0].hisaddr = pin.s_addr;
		    break;
		case RAD_SESSION_TIMEOUT:
		    maxconnect = rad_cvt_int(attrval);
		    syslog(LOG_ERR,"Session-Timeout: %d sec.",maxconnect);
		    break;
#ifdef CBCP
                case RAD_ASCEND_CBCP_MODE:
                        cbcp[0].us_type = rad_cvt_int(attrval);
                        break;
                case RAD_CALLBACK_NUMBER:
                        strcpy(cbcp[0].us_number,
                               rad_cvt_string(attrval, attrlen));
                        break;
#endif /* CBCP */
		case RAD_REPLY_MESSAGE:
		    s = rad_cvt_string(attrval, attrlen);
		    syslog(LOG_WARNING, "Radius server reply: %s", s);
		    free(s);
		    break;
#ifdef PPP_FILTER
		case RAD_FILTER_ID:
		    pc.linktype = DLT_PPP;
		    pc.snapshot = PPP_HDRLEN;
		    s = rad_cvt_string(attrval, attrlen);
		    s1 = (char*)get_filter(s);
		    if (s1 == NULL)
			syslog(LOG_WARNING, "Can't apply pass-filter: %s", s);
		    if (pcap_compile(&pc, &pass_filter, s1, 1, netmask) == 0)
				syslog(LOG_DEBUG, "Apply pass-filter: %s", s);
		    else syslog(LOG_WARNING, "Can't apply pass-filter: %s", s);
		    free(s);free(s1);
		    break;
#endif
		default:
		    break;
	    } /* switch (attrtype) */
	    ret = RAD_SUCCESS;
	} /* while ((attrtype = rad_get_attr(rh, &attrval, &attrlen)) > 0) */
    if (sr == RAD_ACCESS_ACCEPT) {
        ret = RAD_SUCCESS;
        logged_in = TRUE;
	 }
    rad_close(rh);
    return ret;
    
}

int rad_pap_auth(char *user,char *passwd) {
    struct rad_handle *rh;
    int ret;

    rh = rad_auth_open();
    rad_config(rh, NULL);
    rad_create_request(rh, RAD_ACCESS_REQUEST);
    rad_put_string(rh, RAD_USER_NAME, user);
    strcpy(peer_authname,user);
    rad_put_string(rh, RAD_USER_PASSWORD, passwd);

    if((radlogin(rh))== RAD_FAILURE ) ret = UPAP_AUTHNAK;
        else ret = UPAP_AUTHACK;
    return ret;
}

int rad_chap_auth(char *usern, u_char *remmd,int remmd_len, chap_state *cstate) {
    struct rad_handle *rh;
    char cpassword[MAX_RESPONSE_LENGTH + 1];
    
    rh = rad_auth_open();
    rad_config(rh, NULL);
    rad_create_request(rh, RAD_ACCESS_REQUEST);
    rad_put_string(rh, RAD_USER_NAME, usern);
    strcpy(peer_authname,usern);
    switch (cstate->chal_type) {
	case CHAP_DIGEST_MD5:
	syslog(LOG_ERR,"CHAP_MD");
	    cpassword[0] = cstate->chal_id;
	    memcpy(&cpassword[1], remmd, MD5_SIGNATURE_SIZE);
	    rad_put_attr(rh,RAD_CHAP_CHALLENGE,cstate->challenge,cstate->chal_len);
	    rad_put_attr(rh,RAD_CHAP_PASSWORD,cpassword,MD5_SIGNATURE_SIZE + 1);
	break;
    default:
	break;
    }

    if((radlogin(rh))== RAD_FAILURE ) return CHAP_FAILURE;
        else return CHAP_SUCCESS;
}

static struct rad_handle *rad_acct_init(void) {
    struct rad_handle *rah;
    struct in_addr pin;
    
    rah = rad_acct_open();
    if (rad_config(rah, NULL)) return NULL;
    if(rah == NULL ) return NULL;
    rad_create_request(rah, RAD_ACCOUNTING_REQUEST);
    if (rad_put_int(rah, RAD_LOGIN_SERVICE, getpid())) return NULL;
    if (rad_put_string(rah, RAD_ACCT_SESSION_ID, radacc_session_id))  return NULL;
    if (rad_put_int(rah,RAD_SERVICE_TYPE, RAD_VPN)) return NULL;
    if (rad_put_int(rah, RAD_FRAMED_PROTOCOL, RAD_PPP)) return NULL;
    if (rad_put_string(rah, RAD_USER_NAME, peer_authname)) return NULL;
    if (rad_put_int(rah, RAD_NAS_PORT, ifunit)) return NULL;

    memcpy(&pin.s_addr, &ipcp_wantoptions[0].hisaddr,sizeof(pin.s_addr));
    if (rad_put_addr(rah, RAD_FRAMED_IP_ADDRESS, pin)) return NULL;

    if (rad_put_int(rah, RAD_ACCT_AUTHENTIC, RAD_AUTH_RADIUS)) return NULL;
    if (rad_put_int(rah, RAD_NAS_PORT_TYPE, RAD_VIRTUAL)) return NULL;

    if (rad_put_string(rah, RAD_CALLING_STATION_ID, clid)) return NULL;
    if (rad_put_string(rah, RAD_CALLED_STATION_ID, cid)) return NULL;
    return rah;    
}

int rad_start(void) {
	struct rad_handle *rah;
	int ret;
	extern time_t stime;
        rah = rad_acct_init();
        rad_put_int(rah, RAD_ACCT_STATUS_TYPE, RAD_START);
        ret = rad_fast_send_request(rah);
	(void) time(&stime);
	rad_close(rah);
	return ret;
}


int rad_alive(void) {
	struct rad_handle *rah;
	int s,ret;
	struct in_addr pin;
	struct ifreq ifr;
	struct ifpppstatsreq cur; 
	extern time_t stime,etime;
	
	(void) time(&etime);
        rah = rad_acct_init();
        rad_put_int(rah, RAD_ACCT_STATUS_TYPE, RAD_ALIVE);
	rad_put_int(rah, RAD_ACCT_SESSION_TIME, (int) (etime - stime));

	s = socket(AF_INET, SOCK_DGRAM, 0);
	strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name));
	ioctl(s, SIOCGIFFLAGS, (caddr_t) & ifr);
	memset(&cur, 0, sizeof(cur));
	strncpy(cur.ifr_name, ifname, sizeof(cur.ifr_name));
	ioctl(s, SIOCGPPPSTATS, &cur);
	pppd_plugin.in_bytes = cur.stats.p.ppp_ibytes;
	pppd_plugin.ou_bytes  = cur.stats.p.ppp_obytes;
	pppd_plugin.in_packet = cur.stats.p.ppp_ipackets;
	pppd_plugin.ou_packet = pppd_plugin.ou_packet;

	rad_put_int(rah, RAD_ACCT_INPUT_OCTETS, pppd_plugin.in_bytes);
	rad_put_int(rah, RAD_ACCT_OUTPUT_OCTETS, pppd_plugin.ou_bytes);
	rad_put_int(rah, RAD_ACCT_INPUT_PACKETS, pppd_plugin.in_packet);
	rad_put_int(rah, RAD_ACCT_OUTPUT_PACKETS, pppd_plugin.ou_packet);
	if(pppd_plugin.in_bytes > in_limit && in_limit ) {
	    syslog(LOG_ERR,"Input limit: > %d",in_limit);
	    lcp_close(0, "Maximum bytes limit");
	}
	if(pppd_plugin.ou_bytes > out_limit && out_limit) {
	    syslog(LOG_ERR,"Output limit: > %d",out_limit); 
	    lcp_close(0, "Maximum bytes limit");
	}
	if(pppd_plugin.in_bytes+pppd_plugin.ou_bytes > traffic_limit && traffic_limit) {
	    syslog(LOG_ERR,"Total traffic  limit: > %d",traffic_limit);
	    lcp_close(0, "Maximum bytes limit");
	}
	ret = rad_fast_send_request(rah);
	rad_close(rah);close(s);
	return ret;
}

int rad_stop(void) {
	struct rad_handle *rah;
	int ret;
	extern time_t stime,etime;

	(void) time(&etime);
	rad_alive();
        rah = rad_acct_init();
        rad_put_int(rah, RAD_ACCT_STATUS_TYPE, RAD_STOP);
	rad_put_int(rah, RAD_ACCT_SESSION_TIME, (int) (etime - stime));
	rad_put_int(rah, RAD_ACCT_INPUT_OCTETS, pppd_plugin.in_bytes);
	rad_put_int(rah, RAD_ACCT_OUTPUT_OCTETS, pppd_plugin.ou_bytes);
	rad_put_int(rah, RAD_ACCT_INPUT_PACKETS, pppd_plugin.in_packet);
	rad_put_int(rah, RAD_ACCT_OUTPUT_PACKETS, pppd_plugin.ou_packet);
	ret = rad_fast_send_request(rah);
	rad_close(rah);
	return ret;
}
#ifdef PPP_FILTER
static char*
get_filter (nfilter)
    char *nfilter;
{
    FILE *fd;
    char buf[MAXWORDLEN];
    int linenum = 0;
    char *filter = NULL;

    if ((fd = fopen(_PATH_FILTERS, "r")) == NULL) {
        syslog(LOG_WARNING, "Unable to open %s", _PATH_FILTERS);
        return filter;
    };

    while (fgets(buf, sizeof buf, fd) != NULL) {
	int len;
	char *fields[2];
	int nfields;
	char msg[128];
	
	linenum++;
	len = strlen(buf);
	/* We know len > 0, else fgets would have returned NULL. */
	if (buf[len - 1] != '\n') {
	    if (len == sizeof buf - 1)
		syslog(LOG_DEBUG, "%s:%d: line too long", _PATH_FILTERS, linenum);
	    else
		syslog(LOG_DEBUG, "%s:%d: missing newline", _PATH_FILTERS, linenum);
	    break;
	}
	buf[len - 1] = '\0';

	/* Extract the fields from the line. */
	nfields = split(buf, fields, 2, msg, sizeof msg);
	if (nfields == -1) {
	    syslog(LOG_DEBUG, "%s:%d: %s", _PATH_FILTERS, linenum, msg);
	    break;
	}
	if (nfields == 0)
	    continue;
	if (nfields < 2) {
	    syslog(LOG_WARNING, "%s:%d: missing filter definition", _PATH_FILTERS, linenum);
	    break;
	}
	if (strcmp(nfilter, fields[0]) == 0) {
	    filter = (char *) malloc(MAXWORDLEN);
	    strcpy(filter, fields[1]);
	    break;
	}
    }

    memset(buf, 0, sizeof buf);
    fclose(fd);

    return filter;
}

/*
 * Destructively split a string into fields separated by white space.
 * `#' at the beginning of a field begins a comment that extends to the
 * end of the string.  Fields may be quoted with `"'.  Inside quoted
 * strings, the backslash escapes `\"' and `\\' are honored.
 *
 * Pointers to up to the first maxfields fields are stored in the fields
 * array.  Missing fields get NULL pointers.
 *
 * The return value is the actual number of fields parsed, and is always
 * <= maxfields.
 *
 * On a syntax error, places a message in the msg string, and returns -1.
 */
static int
split(char *str, char *fields[], int maxfields, char *msg, size_t msglen)
{
	char *p;
	int i;
	static const char ws[] = " \t";

	for (i = 0;  i < maxfields;  i++)
		fields[i] = NULL;
	p = str;
	i = 0;
	while (*p != '\0') {
		p += strspn(p, ws);
		if (*p == '#' || *p == '\0')
			break;
		if (i >= maxfields) {
			snprintf(msg, msglen, "line has too many fields");
			return -1;
		}
		if (*p == '"') {
			char *dst;

			dst = ++p;
			fields[i] = dst;
			while (*p != '"') {
				if (*p == '\\') {
					p++;
					if (*p != '"' && *p != '\\' &&
					    *p != '\0') {
						snprintf(msg, msglen,
						    "invalid `\\' escape");
						return -1;
					}
				}
				if (*p == '\0') {
					snprintf(msg, msglen,
					    "unterminated quoted string");
					return -1;
				}
				*dst++ = *p++;
			}
			*dst = '\0';
			p++;
			if (*fields[i] == '\0') {
				snprintf(msg, msglen,
				    "empty quoted string not permitted");
				return -1;
			}
			if (*p != '\0' && strspn(p, ws) == 0) {
				snprintf(msg, msglen, "quoted string not"
				    " followed by white space");
				return -1;
			}
		} else {
			fields[i] = p;
			p += strcspn(p, ws);
			if (*p != '\0')
				*p++ = '\0';
		}
		i++;
	}
	return i;
}
#endif /* PPP_FILTER */
