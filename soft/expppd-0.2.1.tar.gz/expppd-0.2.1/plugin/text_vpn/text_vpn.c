#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <net/if_ppp.h>
#include <sys/ioctl.h> 
#include <netinet/in.h>
#include <md5.h>
#include "chap.h"

#include <syslog.h>
#include "pppd.h"
#include "fsm.h"
#include "ipcp.h"
#include "upap.h"

#ifdef	CBCP
#include "lcp.h"
#include "cbcp.h"
#endif

#include "plugin.h"

#ifdef PPP_FILTER
#include <pcap.h>
#include <pcap-int.h>   /* XXX: To get struct pcap */
#define _PATH_FILTERS   "/etc/ppp/filters"
#endif

#define _PATH_USER	"/etc/ppp/user"
#define _PATH_STAT	"/etc/ppp/user/stat.txt"


int text_init(void);
int text_pap_auth(char *user,char *passwd);
int text_chap_auth(char *usern, u_char *remmd,int remmd_len, chap_state *cstate);
int text_start(void);
int text_stop(void);
int text_alive(void);
static int ip_up(void);
static int ip_down(void);
static int set_attr(char *user);

static char *get_param(char *login,char *param);
static int write_param(char *,char *,char *);
static int write_param_int(char *,char *,int);
static int get_param_int(char *login,char *param);
#ifdef PPP_FILTER 
static char *get_filter __P((char *));
static int  split __P((char *, char *[], int, char *, size_t));
#endif

static char *clid;
static char *cid;
static int shape = 0;
static int traffic_limit = 0;
static int in_limit = 0;
static int out_limit = 0;
static int return_code = 0;
static time_t s_time,e_time;


struct plugins pppd_plugin = {
    "expppd text VPN plugin",
    text_init,
    text_pap_auth,
    text_chap_auth,
    text_start,
    text_alive,
    text_stop,
    ip_up,
    ip_down,
// Data
    0,
    0,
    0,
    0
};

int text_init(void) {
    if((clid=(char*)getenv("clid")) == NULL ) clid = "unknown";
    if((cid=(char*)getenv("cid")) == NULL ) cid = "unknown";
}


static int set_attr(char *user) {
    char *ip;
    struct in_addr pin;
#ifdef CBCP
    lcp_options *go = &lcp_gotoptions[0];
#endif /* CBCP */
    
    // IP address
    if((ip = get_param(user,"ip"))!=NULL) {
	inet_aton(ip,&pin);
	if (pin.s_addr != 0xFEFFFFFF) ipcp_wantoptions[0].hisaddr = pin.s_addr; }

    shape = get_param_int(user,"shape");

    if((traffic_limit = get_param_int(user,"traffic")) < 0 )
			lcp_close(0, "Traffic limit");
    if((in_limit = get_param_int(user,"in_traffic")) < 0 )
			lcp_close(0, "Input traffic limit");
    if((out_limit = get_param_int(user,"out_traffic")) < 0 )
			lcp_close(0, "Output traffic limit");
}

int text_pap_auth(char *user,char *passwd) {
    int ret;
    char *pas;
    ret = UPAP_AUTHNAK;
    pas = get_param(user,"password");
    if(pas == NULL) {syslog(LOG_ERR,"Password not found: %s",user); return ret;}
    if(strlen(pas) == strlen(passwd) && !strncmp(pas,passwd,strlen(pas)) ) ret = UPAP_AUTHACK;
    strcpy(peer_authname,user);
    set_attr(user);
    return ret;
}

//int text_chap_auth(char *usern, u_char *remmd,int remmd_len, chap_state *cstate) {
//}


int text_chap_auth(char *usern, u_char *remmd,int remmd_len, chap_state *cstate) {
    int ret;
    char *pas;
    
    MD5_CTX mdContext;

    u_char hash[MD5_SIGNATURE_SIZE];
    ret = CHAP_FAILURE;
    
    pas = get_param(usern,"password");
    switch (cstate->chal_type) { 
	case CHAP_DIGEST_MD5:
	if (remmd_len != MD5_SIGNATURE_SIZE) break;
        MD5Init(&mdContext);
        MD5Update(&mdContext, &cstate->chal_id, 1);
        MD5Update(&mdContext, pas, strlen(pas));
        MD5Update(&mdContext, cstate->challenge, cstate->chal_len);
        MD5Final(hash, &mdContext); 
        if (memcmp (hash, remmd, MD5_SIGNATURE_SIZE) == 0)
    	    ret = CHAP_SUCCESS;
        break;

	default:
	    CHAPDEBUG((LOG_INFO, "unknown digest type %d", cstate->chal_type));
	}
    strcpy(peer_authname,usern);
    set_attr(usern);
    return ret;
}

int text_start(void) {
    int ret = 0;
    extern time_t stime,etime;
    (void) time(&stime);
    return ret;
}

int text_alive(void) {
	int s,ret;
	struct in_addr pin;
	struct ifreq ifr;
	struct ifpppstatsreq cur; 
	extern time_t stime,etime;
	char buf[1024];
	
	(void) time(&etime);
	s = socket(AF_INET, SOCK_DGRAM, 0);
	strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name));
	ioctl(s, SIOCGIFFLAGS, (caddr_t) & ifr);
	memset(&cur, 0, sizeof(cur));
	strncpy(cur.ifr_name, ifname, sizeof(cur.ifr_name));
	ioctl(s, SIOCGPPPSTATS, &cur);
	pppd_plugin.in_bytes = cur.stats.p.ppp_ibytes;
	pppd_plugin.ou_bytes  = cur.stats.p.ppp_obytes;
	pppd_plugin.in_packet = cur.stats.p.ppp_ipackets;
	pppd_plugin.ou_packet = pppd_plugin.ou_packet;

	if(pppd_plugin.in_bytes > in_limit && in_limit ) {
	    syslog(LOG_ERR,"Input limit: > %d",in_limit);
	    lcp_close(0, "Maximum bytes limit");
	}
	if(pppd_plugin.ou_bytes > out_limit && out_limit) {
	    syslog(LOG_ERR,"Output limit: > %d",out_limit); 
	    lcp_close(0, "Maximum bytes limit");
	}
	if(pppd_plugin.in_bytes+pppd_plugin.ou_bytes > traffic_limit && traffic_limit) {
	    syslog(LOG_ERR,"Total traffic  limit: > %d",traffic_limit);
	    lcp_close(0, "Maximum bytes limit");
	}
	close(s);
	return ret;
}

int text_stop(void) {
    int ret=0;
    unsigned long t_b;
    
    FILE *fl;
    char buf[1024];
    extern time_t stime,etime;
    (void) time(&etime);
    
    if((t_b = get_param_int(peer_authname,"traffic"))!= 0) {
	t_b-=(pppd_plugin.in_bytes+pppd_plugin.ou_bytes);
	write_param_int(peer_authname,"traffic",t_b);
    }

    if((t_b = get_param_int(peer_authname,"in_traffic"))!= 0) {
	t_b-=pppd_plugin.in_bytes;
	write_param_int(peer_authname,"in_traffic",t_b);
    }

    if((t_b = get_param_int(peer_authname,"out_traffic"))!= 0) {
	t_b-=pppd_plugin.ou_bytes;
	write_param_int(peer_authname,"out_traffic",t_b);
    }

    sprintf(buf,"%s\t%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t%d\t%s\n",
		peer_authname,stime,etime,etime-stime,pppd_plugin.in_bytes,
		pppd_plugin.ou_bytes,getpid(),ifunit,
		inet_ntoa(ipcp_wantoptions[0].hisaddr));
    fl = fopen(_PATH_STAT,"a");
    fputs(buf,fl);fclose(fl);
    return ret;
}

static int ip_up(void) {
    char *argv[7],strspeed[32];
    sprintf(strspeed, "%d", shape);
    argv[0] = "/etc/ppp/shape.ppp";
    argv[1] = "Start";
    argv[2] = ifname;
    argv[3] = strspeed;
    argv[4] = peer_authname;
    argv[5] = devnam;
    argv[6] = NULL;
    run_program("/etc/ppp/shape.ppp", argv, 0);
}

static int ip_down(void) {
    char *argv[7],strspeed[32];
    sprintf(strspeed, "%d", shape);
    argv[0] = "/etc/ppp/shape.ppp";
    argv[1] = "Stop";
    argv[2] = ifname;
    argv[3] = strspeed;
    argv[4] = peer_authname;
    argv[5] = devnam;
    argv[6] = NULL;
    run_program("/etc/ppp/shape.ppp", argv, 0);
}

static int write_param(char *login,char *param,char *data) {
    char path[128];
    FILE *fl;

    sprintf(path,"%s/%s/%s\0",_PATH_USER,login,param);
    if((fl=fopen(path,"w")) == NULL) {
	syslog(LOG_ERR,"Write failure: %s",path);
	return -1; }
    fputs(data,fl);
    fclose(fl);
}

static int write_param_int(char *login,char *param,int data) {
    char path[128];
    FILE *fl;

    sprintf(path,"%s/%s/%s\0",_PATH_USER,login,param);
    if((fl=fopen(path,"w")) == NULL) {
	syslog(LOG_ERR,"Write failure: %s",path);
	return -1; }
    fprintf(fl,"%d",data);
    fclose(fl);
}

static int get_param_int(char *login,char *param) {
    char *rt;
    int ret;
    rt = get_param(login,param);
    if(rt == NULL) return 0;
    ret = atol(rt);free(rt);
    return ret;
}

static char *get_param(char *login,char *param) {
    FILE *fl;
    int c_r;
    char path[128],buf[1024];
    char *ret;
    sprintf(path,"%s/%s/%s\0",_PATH_USER,login,param);

    if(!access(path,R_OK)) {
	if((fl=fopen(path,"r")) == NULL )
	    { syslog(LOG_ERR,"Unable to open: %s",path);return NULL; }
	fgets(buf,1024,fl);
	ret = (char*)malloc(strlen(buf)+1);
	strcpy(ret,buf);fclose(fl);
	ret[strlen(buf)]='\0';
	return ret;
    } else return NULL;

}

#ifdef PPP_FILTER
static char*
get_filter (nfilter)
    char *nfilter;
{
    FILE *fd;
    char buf[MAXWORDLEN];
    int linenum = 0;
    char *filter = NULL;

    if ((fd = fopen(_PATH_FILTERS, "r")) == NULL) {
        syslog(LOG_WARNING, "Unable to open %s", _PATH_FILTERS);
        return filter;
    };

    while (fgets(buf, sizeof buf, fd) != NULL) {
	int len;
	char *fields[2];
	int nfields;
	char msg[128];
	
	linenum++;
	len = strlen(buf);
	/* We know len > 0, else fgets would have returned NULL. */
	if (buf[len - 1] != '\n') {
	    if (len == sizeof buf - 1)
		syslog(LOG_DEBUG, "%s:%d: line too long", _PATH_FILTERS, linenum);
	    else
		syslog(LOG_DEBUG, "%s:%d: missing newline", _PATH_FILTERS, linenum);
	    break;
	}
	buf[len - 1] = '\0';

	/* Extract the fields from the line. */
	nfields = split(buf, fields, 2, msg, sizeof msg);
	if (nfields == -1) {
	    syslog(LOG_DEBUG, "%s:%d: %s", _PATH_FILTERS, linenum, msg);
	    break;
	}
	if (nfields == 0)
	    continue;
	if (nfields < 2) {
	    syslog(LOG_WARNING, "%s:%d: missing filter definition", _PATH_FILTERS, linenum);
	    break;
	}
	if (strcmp(nfilter, fields[0]) == 0) {
	    filter = (char *) malloc(MAXWORDLEN);
	    strcpy(filter, fields[1]);
	    break;
	}
    }

    memset(buf, 0, sizeof buf);
    fclose(fd);

    return filter;
}

static int
split(char *str, char *fields[], int maxfields, char *msg, size_t msglen)
{
	char *p;
	int i;
	static const char ws[] = " \t";

	for (i = 0;  i < maxfields;  i++)
		fields[i] = NULL;
	p = str;
	i = 0;
	while (*p != '\0') {
		p += strspn(p, ws);
		if (*p == '#' || *p == '\0')
			break;
		if (i >= maxfields) {
			snprintf(msg, msglen, "line has too many fields");
			return -1;
		}
		if (*p == '"') {
			char *dst;

			dst = ++p;
			fields[i] = dst;
			while (*p != '"') {
				if (*p == '\\') {
					p++;
					if (*p != '"' && *p != '\\' &&
					    *p != '\0') {
						snprintf(msg, msglen,
						    "invalid `\\' escape");
						return -1;
					}
				}
				if (*p == '\0') {
					snprintf(msg, msglen,
					    "unterminated quoted string");
					return -1;
				}
				*dst++ = *p++;
			}
			*dst = '\0';
			p++;
			if (*fields[i] == '\0') {
				snprintf(msg, msglen,
				    "empty quoted string not permitted");
				return -1;
			}
			if (*p != '\0' && strspn(p, ws) == 0) {
				snprintf(msg, msglen, "quoted string not"
				    " followed by white space");
				return -1;
			}
		} else {
			fields[i] = p;
			p += strcspn(p, ws);
			if (*p != '\0')
				*p++ = '\0';
		}
		i++;
	}
	return i;
}
#endif /* PPP_FILTER */

