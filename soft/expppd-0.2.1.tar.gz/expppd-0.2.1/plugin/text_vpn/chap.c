switch (cstate->chal_type) { 
    case CHAP_DIGEST_MD5:		/* only MD5 is defined for now */
    if (remmd_len != MD5_SIGNATURE_SIZE)
	break;			/* it's not even the right length */
        MD5Init(&mdContext);
        MD5Update(&mdContext, &cstate->chal_id, 1);
        MD5Update(&mdContext, secret, secret_len);
        MD5Update(&mdContext, cstate->challenge, cstate->chal_len);
        MD5Final(hash, &mdContext); 
        if (memcmp (hash, remmd, MD5_SIGNATURE_SIZE) == 0)
    	code = CHAP_SUCCESS;	/* they are the same! */
        break;

	default:
	    CHAPDEBUG((LOG_INFO, "unknown digest type %d", cstate->chal_type));
	}
