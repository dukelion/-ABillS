/* $Id: patchlevel.h,v 1.2 2003/08/12 13:54:37 shs Exp $ */
#define	PATCHLEVEL	6

#define VERSION		"2.3.2"
#ifdef CBCP
#define IMPLEMENTATION	".plugin.cbcp"
#else
#define IMPLEMENTATION	".plugin"
#endif /* CBCP */
#define DATE		"11/08/2003"

