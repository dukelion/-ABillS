#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <syslog.h>
#include "plugin.h"

#include "pppd.h"
#include "cbcp.h"
#include "fsm.h"
#include "lcp.h"
#include "ipcp.h"
#include "upap.h"

extern void network_phase  __P((int));

static void cbcp_init      __P((int));
static void cbcp_open      __P((int));
static void cbcp_input     __P((int, u_char *, int));
static void cbcp_recvresp  __P((int, u_char *, int));
static void cbcp_sendack   __P((int));
static int  cbcp_printpkt  __P((u_char *, int,void (*) __P((void *, char *, ...)),
                            void *));

/*
 * Protocol entry points.
 */

struct protent cbcp_protent = {
    PPP_CBCP,
    cbcp_init,
    cbcp_input,
    NULL,
    NULL,
    NULL,
    cbcp_open,
    NULL,
    cbcp_printpkt,
    NULL,
    0,
    "CBCP",
    NULL,
    NULL,
    NULL
};

cbcp_state cbcp[NUM_PPP];	

static void
cbcp_init(iface)
    int iface;
{
    cbcp_state *us;

    us = &cbcp[iface];
    memset(us, 0, sizeof(cbcp_state));
    us->us_delay = 10;
    us->us_unit = iface;
    us->us_type = CB_CONF_NO;
}

/*
 * Open CBCP
 */
static void
cbcp_open(unit)
    int unit;
{
    u_char buf[256];
    u_char *bufp = buf;
    int len = 0;

    u_char *outp;
    int outlen = 0;

    cbcp_state *us = &cbcp[unit];

    outp = outpacket_buf;
    
    LCPDEBUG((LOG_DEBUG, "cbcp_open: callback type = %d", us->us_type));

    (us->us_id)++;

    switch(us->us_type) {

    case CB_CONF_NO:
      PUTCHAR(CB_CONF_NO, bufp);	/* Callback type */
      PUTCHAR(2 , bufp);		/* Length */
      len += 2;
      break;

    case CB_CONF_USER:
      PUTCHAR(CB_CONF_USER, bufp);	/* Callback type */
      PUTCHAR(5 , bufp);		/* Length */
      PUTCHAR(0, bufp);			/* Delay */
      PUTCHAR(1, bufp);			/* Add type */
      PUTCHAR(0, bufp);			/* Address */
      len += 5;
      break;

    case CB_CONF_ADMIN:
      PUTCHAR(CB_CONF_ADMIN, bufp);	/* Callback type */
      PUTCHAR(3, bufp)			/* Length */
      PUTCHAR(0, bufp);			/* Delay */
      len += 3;
      break;

    default:
      syslog(LOG_ERR, "cbcp_open: unsupported callback type (%d)",
      		us->us_type);
      kill_link = 1;
      return;
    }

    LCPDEBUG((LOG_DEBUG, "cbcp_open: send request"));

    outlen = CBCP_MINLEN + len;

    MAKEHEADER(outp, PPP_CBCP);			/* Header */
    PUTCHAR(CBCP_REQ, outp);			/* CBCP request */
    PUTCHAR(us->us_id, outp);			/* Id */
    PUTSHORT(outlen, outp);			/* Length */
    BCOPY(buf, outp, len);			/* Callback options */

    output(1, outpacket_buf, outlen + PPP_HDRLEN);
}

/*
 * Process an incoming CBCP packet
 */
static void
cbcp_input(unit, inpacket, pktlen)
    int unit;
    u_char *inpacket;
    int pktlen;
{
    u_char *inp;
    u_char code;
    u_char id;
    u_short len;

    cbcp_state *us = &cbcp[unit];
    inp = inpacket;

    LCPDEBUG((LOG_DEBUG,"cbcp_input: reciev CBCP packet"));

    if (pktlen < CBCP_MINLEN) {
        syslog(LOG_ERR, "cbcp_input: CBCP packet is too small");
        return;
    }

    GETCHAR(code, inp);
    GETCHAR(id, inp);
    GETSHORT(len, inp);

    if (len != pktlen) {
        syslog(LOG_ERR, "cbcp_input: invalid length");
        return;
    }

    if (us->us_id == 0) {
        syslog(LOG_ERR, "cbcp_input: we don't expect any packet");
        return;
    }

    len -= CBCP_MINLEN;

    switch(code) {
    case CBCP_REQ:
        syslog(LOG_ERR, "cbcp_input: CBCP_REQ received (not expected)");
        break;

    case CBCP_RESP:
        LCPDEBUG((LOG_DEBUG, "cbcp_input: CBCP_RESP received"));
        cbcp_recvresp(unit, inp, len);
        break;

    case CBCP_ACK:
        syslog(LOG_ERR, "cbcp input: CBCP_ACK received (not expected)");
        break;

    default:
        break;
    }
}

/*
 * Process a CBCP response
 */
static void
cbcp_recvresp(unit, inpacket, pktlen)
    int unit;
    u_char *inpacket;
    int pktlen;
{
    cbcp_state *us = &cbcp[unit];

    u_char type;
    u_char delay = 0;
    u_char addr_type;
    int opt_len;

    if (pktlen < 2) {  
        syslog(LOG_ERR, "cbcp_recvresp: packet is too small");
        return;
    }

    GETCHAR(type, inpacket);
    GETCHAR(opt_len, inpacket);

    if (opt_len < 3 && (type == CB_CONF_ADMIN || type == CB_CONF_USER)) {
        syslog(LOG_ERR, "cbcp_recvresp: not specified delay");
      	kill_link = 1;
	return;
    }

    if (opt_len > 2) {
        GETCHAR(delay, inpacket);
        us->us_delay = (delay > 30 ? 30 : delay);
    }
    
    if (type != us->us_type) {
	syslog(LOG_ERR, "cbcp_recvresp: wrong cbcp_type =  %d, "
	    	"expect cbcp_type = %d", type, us->us_type);
      	kill_link = 1;
	return;
    }

    LCPDEBUG((LOG_DEBUG, "cbcp_recvresp: reciev cbcptype = %d", type));

    switch(type) {
    case CB_CONF_NO:
    case CB_CONF_ADMIN:
	/* Do nothing */

	us->us_recvresp = TRUE;
        break;
    case CB_CONF_USER:
	if (opt_len > 4) {
	   GETCHAR(addr_type, inpacket);
	   if (addr_type != CBCP_ADDR_TYPE_PSTN) {
	        syslog(LOG_ERR, "cbcp_recvresp: wrong addr_type =  %d",
	            addr_type);
      	        kill_link = 1;
	        return;
	   }
	   if ((opt_len - 4 > sizeof(us->us_number)) || 
	       (opt_len - 4 > cbcpmaxdigits + 1)) {
	        syslog(LOG_ERR, "cbcp_recvresp: too long callback number "
	        	"(%d digits) - allowed %d", opt_len - (4 + 1),
	        	cbcpmaxdigits);
	        kill_link = 1;
	        return;
	   }
           BCOPY(inpacket, us->us_number, opt_len - 4);

           LCPDEBUG((LOG_DEBUG, "cbcp_recvresp: callback number = %s",
           	 us->us_number));
	} else {
	    syslog(LOG_ERR, "cbcp_recvresp: not specified callback number");
	    kill_link = 1;
	    return;
	}

	us->us_recvresp = TRUE;
        break;
    }

    cbcp_sendack(unit);
}

/*
 * Send a CBCP acknowledgment
 */
static void
cbcp_sendack(unit)
    int unit;
{
    u_char buf[256];
    u_char *bufp = buf;
    int len = 0;

    u_char *outp;
    int outlen = 0;

    cbcp_state *us = &cbcp[unit];

    outp = outpacket_buf;

    if (!us->us_recvresp) {
	syslog(LOG_ERR, "cbcp_sendack: no valid response was recieved");
      	kill_link = 1;
	return;
    }

    switch(us->us_type) {

    case CB_CONF_NO:
	len = 2;
	PUTCHAR(CB_CONF_NO, bufp);
	PUTCHAR(len , bufp);
        break;

    case CB_CONF_USER:
        len = 5 + strlen(us->us_number);
	PUTCHAR(CB_CONF_USER, bufp);
	PUTCHAR(len, bufp);
	PUTCHAR(us->us_delay, bufp);
	PUTCHAR(CBCP_ADDR_TYPE_PSTN, bufp);
	BCOPY(us->us_number, bufp, len - 4);
	break;

    case CB_CONF_ADMIN:
	len = 3;
	PUTCHAR(CB_CONF_ADMIN, bufp);
	PUTCHAR(len, bufp);
	PUTCHAR(us->us_delay, bufp);
	break;
    }

    LCPDEBUG((LOG_DEBUG, "cbcp_sendack: send ack"));

    outlen = CBCP_MINLEN + len;

    MAKEHEADER(outp, PPP_CBCP);
    PUTCHAR(CBCP_ACK, outp);
    PUTCHAR(us->us_id, outp);
    PUTSHORT(outlen, outp);
    BCOPY(buf, outp, len);

    output(1, outpacket_buf, outlen + PPP_HDRLEN);
    
    if (us->us_type == CB_CONF_NO) {
        /* Doing accounting */
        if (useplugin) {
            if(plugin->stop !=NULL ) plugin->stop(); }
    }

    if (us->us_type == CB_CONF_ADMIN || us->us_type == CB_CONF_USER) {
        /* Doing callback */
        phase = PHASE_TERMINATE;
        return;
    } else {
        /* Go to Network phase */
        network_phase(unit);
    }
}

char *cbcp_codenames[] = {
    "Request", "Response", "Ack"
};

char *cbcp_optionnames[] = {
    "NoCallback",
    "UserDefined",
    "AdminDefined",
    "List"
};

/* pretty print a packet */
static int
cbcp_printpkt(p, plen, printer, arg)
    u_char *p;
    int plen;
    void (*printer) __P((void *, char *, ...));
    void *arg;
{
    int code, opt, id, len, olen, delay;
    u_char *pstart;

    if (plen < HEADERLEN)
	return 0;
    pstart = p;
    GETCHAR(code, p);
    GETCHAR(id, p);
    GETSHORT(len, p);
    if (len < HEADERLEN || len > plen)
	return 0;

    if (code >= 1 && code <= sizeof(cbcp_codenames) / sizeof(char *))
	printer(arg, " %s", cbcp_codenames[code-1]);
    else
	printer(arg, " code=0x%x", code); 

    printer(arg, " id=0x%x", id);
    len -= HEADERLEN;

    switch (code) {
    case CBCP_REQ:
    case CBCP_RESP:
    case CBCP_ACK:
        while(len >= 2) {
	    GETCHAR(opt, p);
	    GETCHAR(olen, p);

	    if (olen < 2 || olen > len) {
	        break;
	    }

	    printer(arg, " <");
	    len -= olen;

	    if (opt >= 1 && opt <= sizeof(cbcp_optionnames) / sizeof(char *))
	    	printer(arg, " %s", cbcp_optionnames[opt-1]);
	    else
	        printer(arg, " option=0x%x", opt); 

	    if (olen > 2) {
	        GETCHAR(delay, p);
		printer(arg, " delay = %d", delay);
	    }

	    if (olen > 3) {
	        int addrt;
		char str[256];

		GETCHAR(addrt, p);
		memcpy(str, p, olen - 4);
		str[olen - 4] = 0;
		printer(arg, " number = %s", str);
	    }
	    printer(arg, ">");
	    break;
	}

    default:
	break;
    }

    for (; len > 0; --len) {
	GETCHAR(code, p);
	printer(arg, " %.2x", code);
    }

    return p - pstart;
}

