#ifndef CBCP_H
#define CBCP_H

typedef struct cbcp_state {
    int    us_unit;		/* Interface unit number */
    u_char us_id;		/* Current id */
    int    us_type;		/* Callback type */
    int    us_delay;		/* Callback delay */
    char   us_number[64];	/* Telephone Number */
    int    us_recvresp;		/* We are reciev properly response */
} cbcp_state;

extern cbcp_state cbcp[];

extern struct protent cbcp_protent;

#define CBCP_MINLEN 4

#define CBCP_REQ    1
#define CBCP_RESP   2
#define CBCP_ACK    3

#define CB_CONF_NO		1
#define CB_CONF_USER		2
#define CB_CONF_ADMIN		3
#define CB_CONF_LIST		4

#define CBCP_ADDR_TYPE_PSTN	1

#define RAD_ASCEND_CBCP_MODE			113	/* Integer */
	#define RAD_CBCP_NO_CALLBACK		1
	#define RAD_CBCP_USER_CALLBACK		2
	#define RAD_CBCP_PROFILE_CALLBACK	3
	#define RAD_CBCP_USER_OR_NO		7	/* Not supported */

#endif
