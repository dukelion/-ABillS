/* $Id: patchlevel.h,v 1.9 1998/06/20 18:02:14 peter Exp $ */
#define	PATCHLEVEL	5

#define VERSION		"2.3"
#ifdef CBCP
#define IMPLEMENTATION	".radius.cbcp"
#else
#define IMPLEMENTATION	".radius"
#endif /* CBCP */
#define DATE		"4 May 1998"
